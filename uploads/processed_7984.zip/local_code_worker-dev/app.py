import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import requests
import zipfile
import os
import tempfile
from github import Github
import threading

class LocalCodeWorker:
    def __init__(self, root):
        self.root = root
        self.root.title("Local Code Worker")
        self.root.geometry("800x600")
        
        # Создаем вкладки
        self.notebook = ttk.Notebook(root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Вкладка для GitHub
        self.github_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.github_frame, text="GitHub")
        
        # Вкладка для загрузки архива
        self.zip_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.zip_frame, text="Upload ZIP")
        
        # Переменные для хранения данных
        self.github_repo_url = tk.StringVar()
        self.github_branch = tk.StringVar(value="main")
        self.zip_file_path = tk.StringVar()
        
        # Настройка GitHub вкладки
        self.setup_github_tab()
        
        # Настройка ZIP вкладки
        self.setup_zip_tab()
        
    def setup_github_tab(self):
        # Фрейм для GitHub ввода
        input_frame = ttk.Frame(self.github_frame)
        input_frame.pack(fill=tk.X, padx=10, pady=10)
        
        # URL репозитория
        ttk.Label(input_frame, text="Repository URL:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=5)
        repo_entry = ttk.Entry(input_frame, textvariable=self.github_repo_url, width=50)
        repo_entry.grid(row=0, column=1, sticky=tk.W, padx=5, pady=5)
        
        # Название ветки
        ttk.Label(input_frame, text="Branch:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=5)
        branch_entry = ttk.Entry(input_frame, textvariable=self.github_branch, width=50)
        branch_entry.grid(row=1, column=1, sticky=tk.W, padx=5, pady=5)
        
        # Кнопка для получения кода
        get_code_button = ttk.Button(input_frame, text="Get Code from GitHub", command=self.get_code_from_github)
        get_code_button.grid(row=2, column=0, columnspan=2, pady=10)
        
        # Результат
        result_frame = ttk.LabelFrame(self.github_frame, text="Result")
        result_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.github_result_text = tk.Text(result_frame, wrap=tk.WORD)
        scrollbar = ttk.Scrollbar(result_frame, orient=tk.VERTICAL, command=self.github_result_text.yview)
        self.github_result_text.configure(yscrollcommand=scrollbar.set)
        
        self.github_result_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
    def setup_zip_tab(self):
        # Фрейм для ZIP загрузки
        zip_input_frame = ttk.Frame(self.zip_frame)
        zip_input_frame.pack(fill=tk.X, padx=10, pady=10)
        
        # Выбор файла
        ttk.Label(zip_input_frame, text="Select ZIP file:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=5)
        ttk.Button(zip_input_frame, text="Browse", command=self.browse_zip_file).grid(row=0, column=1, padx=5, pady=5)
        ttk.Label(zip_input_frame, textvariable=self.zip_file_path).grid(row=0, column=2, sticky=tk.W, padx=5, pady=5)
        
        # Кнопка для извлечения кода
        extract_button = ttk.Button(zip_input_frame, text="Extract Code from ZIP", command=self.extract_code_from_zip)
        extract_button.grid(row=1, column=0, columnspan=3, pady=10)
        
        # Результат
        result_frame = ttk.LabelFrame(self.zip_frame, text="Result")
        result_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.zip_result_text = tk.Text(result_frame, wrap=tk.WORD)
        scrollbar = ttk.Scrollbar(result_frame, orient=tk.VERTICAL, command=self.zip_result_text.yview)
        self.zip_result_text.configure(yscrollcommand=scrollbar.set)
        
        self.zip_result_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
    def browse_zip_file(self):
        file_path = filedialog.askopenfilename(
            title="Select ZIP File",
            filetypes=[("ZIP files", "*.zip"), ("All files", "*.*")]
        )
        if file_path:
            self.zip_file_path.set(file_path)
            
    def get_code_from_github(self):
        repo_url = self.github_repo_url.get().strip()
        branch = self.github_branch.get().strip()
        
        if not repo_url:
            messagebox.showerror("Error", "Please enter repository URL")
            return
            
        if not branch:
            branch = "main"
            
        # Запускаем в отдельном потоке, чтобы не блокировать интерфейс
        threading.Thread(target=self._get_code_from_github_thread, args=(repo_url, branch)).start()
        
    def _get_code_from_github_thread(self, repo_url, branch):
        try:
            self.github_result_text.delete(1.0, tk.END)
            self.github_result_text.insert(tk.END, f"Fetching repository from {repo_url}...\n")
            self.root.update()
            
            # Извлекаем имя репозитория из URL
            if repo_url.startswith("https://github.com/"):
                repo_name = repo_url.split("/")[-1]
                owner = repo_url.split("/")[-2]
            else:
                raise ValueError("Invalid GitHub URL format")
                
            # Используем PyGithub для получения репозитория
            g = Github()
            repo = g.get_repo(f"{owner}/{repo_name}")
            
            # Получаем содержимое ветки
            contents = repo.get_contents("", ref=branch)
            
            # Обрабатываем содержимое
            self._process_github_contents(contents, repo, branch)
            
        except Exception as e:
            self.github_result_text.insert(tk.END, f"Error: {str(e)}\n")
            
    def _process_github_contents(self, contents, repo, branch):
        # Обработка содержимого репозитория
        for content_file in contents:
            if content_file.type == "dir":
                # Если это директория, рекурсивно обрабатываем её
                dir_contents = repo.get_contents(content_file.path, ref=branch)
                self._process_github_contents(dir_contents, repo, branch)
            elif content_file.type == "file":
                # Получаем содержимое файла
                file_content = repo.get_contents(content_file.path, ref=branch)
                self.github_result_text.insert(tk.END, f"\n--- File: {content_file.path} ---\n")
                self.github_result_text.insert(tk.END, file_content.decoded_content.decode('utf-8'))
                
        self.github_result_text.insert(tk.END, "\n\nFinished fetching code from GitHub.\n")
        
    def extract_code_from_zip(self):
        zip_path = self.zip_file_path.get().strip()
        
        if not zip_path:
            messagebox.showerror("Error", "Please select a ZIP file")
            return
            
        # Запускаем в отдельном потоке
        threading.Thread(target=self._extract_code_from_zip_thread, args=(zip_path,)).start()
        
    def _extract_code_from_zip_thread(self, zip_path):
        try:
            self.zip_result_text.delete(1.0, tk.END)
            self.zip_result_text.insert(tk.END, f"Extracting code from {zip_path}...\n")
            self.root.update()
            
            # Извлекаем содержимое архива
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                # Получаем список файлов
                file_list = zip_ref.namelist()
                
                # Извлекаем файлы
                for file_name in file_list:
                    if file_name.endswith('/'):  # Пропускаем директории
                        continue
                        
                    # Извлекаем файл
                    with zip_ref.open(file_name) as file:
                        content = file.read()
                        
                    # Показываем содержимое файла
                    self.zip_result_text.insert(tk.END, f"\n--- File: {file_name} ---\n")
                    try:
                        self.zip_result_text.insert(tk.END, content.decode('utf-8'))
                    except UnicodeDecodeError:
                        self.zip_result_text.insert(tk.END, "[Binary file content not shown]\n")
                        
            self.zip_result_text.insert(tk.END, "\n\nFinished extracting code from ZIP.\n")
            
        except Exception as e:
            self.zip_result_text.insert(tk.END, f"Error: {str(e)}\n")

if __name__ == "__main__":
    root = tk.Tk()
    app = LocalCodeWorker(root)
    root.mainloop()