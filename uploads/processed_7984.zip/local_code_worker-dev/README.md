# Local Code Worker

## Features

This application allows you to:
1. Fetch code from GitHub repositories
2. Extract code from ZIP archives

## GitHub Mode

To use the GitHub mode:
1. Enter the repository URL (e.g., https://github.com/username/repo-name)
2. Enter the branch name (default is "main")
3. Click "Get Code from GitHub"

## ZIP Mode

To use the ZIP mode:
1. Select a ZIP file containing code
2. Click "Extract Code from ZIP"

## Requirements

- Python 3.6+
- requests
- PyGithub

## Installation

```bash
pip install -r requirements.txt
```

## Usage

```bash
python src/main.py
```
```

Эти изменения добавляют следующий функционал:

1. **Вкладка GitHub**: Пользователь может ввести URL репозитория и название ветки, после чего получает код из репозитория через API GitHub
2. **Вкладка ZIP**: Пользователь может выбрать ZIP-архив и извлечь из него содержимое кода
3. **Обработка ошибок**: Добавлены сообщения об ошибках для удобства использования
4. **Многопоточность**: Для предотвращения блокировки интерфейса при загрузке данных используются отдельные потоки
5. **Интерфейс**: Улучшенный интерфейс с вкладками для удобного переключения между режимами работы

Для работы с GitHub вам потребуется установить PyGithub:
```bash
pip install PyGithub